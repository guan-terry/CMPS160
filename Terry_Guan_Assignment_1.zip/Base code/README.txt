Terry Guan
1528854
teguan@ucsc.edu

I spent about ~5-8 hours working on this project. I googled a lot of the syntax since this is my first time using javascript/ 
HTML. I also talked a lot to friends in this class about how to do the project, but it didn't really help me because I started 
so early.

my website is https://people.ucsc.edu/~teguan/